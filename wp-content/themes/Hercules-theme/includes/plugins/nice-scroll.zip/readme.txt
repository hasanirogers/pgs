﻿=== WP-Nicescroll ===
Contributors: inuyaksa
License: MIT
Tags: nicescroll, scrollbar, customize, ui, window, ios
Requires at least: 3.0.0
Tested up to: 3.5.0
Stable tag: 2.0.0
 
 
Add nicescroll to your wordpress site, it's a jquery (since 1.5) plugin for nice scrollbars with a very similar ios/mobile style.
Compatible with the most desktop and mobile browsers. (IE6-10, Firefox, Chrome, Safari, Opera, WP7, Blackberry)

== Description ==

With this plugin you can add nicescroll to your Wordpress site.

== Installation ==

1. Create new folder at plugin directory: /wp-content/plugins/wp-nicescroll
2. Upload 'wp-nicescroll.php', 'jnc_admin_set.php', 'jquery.min.js' and 'jquery.nicescroll.min.js' to the '/wp-content/plugins/wp-nicescroll' directory
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Done!

== Frequently Asked Questions ==

First release, please ask!

== Upgrade Notice ==

Nope

== Changelog ==

= 2.0.0 =
* Added jQuery option, when disabled don't load jquery.min included on this package

= 1.2.2 =
* Added new option to set scrollable dom element (default is "html")

= 1.2.0 =
* Next release, based from nicecroll 2.9.5: compatible with IE10 and BlackBerry (PlayBook), more smooth scrolling and cpu-saving optimizations

= 1.0.0 =
* First release, based from nicecroll 2.8.5
